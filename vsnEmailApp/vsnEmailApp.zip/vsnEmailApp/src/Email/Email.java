package Email;

public class Email {
}
